# Error Handling
*   Handle inaccessible web sources or files gracefully by noting the limitation.
*   If critical sources are unavailable, report this limitation clearly.
*   Report tool errors or persistent blockers via `attempt_completion`.