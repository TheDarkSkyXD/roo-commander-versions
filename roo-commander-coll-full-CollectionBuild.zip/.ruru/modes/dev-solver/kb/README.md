+++
id = "KB-LOOKUP-RULE-DEV-SOLVER-V3" # Updated ID based on template version
title = "Standard: dev-solver KB Lookup & Index" # Kept existing title
context_type = "rules"
scope = "Mode-specific knowledge base access"
target_audience = ["dev-solver"] # Replaced placeholder
granularity = "rule"
status = "active"
last_updated = "2025-05-04" # Updated date
# version = "3.0" # Optional: Indicate version change
# related_context = []
tags = ["kb-lookup", "knowledge-base", "rule", "template", "conditional", "research", "mcp", "dev-solver"] # Kept existing specific tags
# relevance = ""
kb_directory = ".ruru/modes/dev-solver/kb/" # Replaced placeholder
+++

# Knowledge Base (KB) Lookup Rule (Conditional + Info Gathering)

**Applies To:** `dev-solver` mode

**Rule:**

Before attempting a task, assess its complexity and novelty.

1.  **Task Assessment:**
    *   Briefly evaluate the task: Is it simple, routine, and low-risk (e.g., standard command, minor text edit)? Or is it complex, novel, high-risk, or ambiguous?
    *   Consider your confidence level in executing the task without specific guidance.

2.  **Conditional KB Consultation:**
    *   **IF** the task is assessed as **complex, novel, high-risk, or uncertain**:
        *   **MUST** consult the dedicated Knowledge Base (KB) directory for this mode located at: `.ruru/modes/dev-solver/kb/`
        *   Follow the KB Scan Procedure below. If the KB is insufficient, proceed to Step 4 (Information Gathering).
    *   **ELSE IF** the task is assessed as **simple, routine, and low-risk**:
        *   KB consultation is **OPTIONAL**. Proceed directly to Step 3 (Apply Knowledge / Execute).
        *   *(Optional but Recommended):* Briefly note in logs/reasoning that KB was skipped due to task simplicity.
    *   **ELSE IF** assessment is **unclear**:
        *   Ask the coordinator/user for guidance on whether KB consultation is needed before proceeding. If directed to consult and KB is insufficient, proceed to Step 4.

**KB Scan Procedure (If Triggered by Step 2):**

1.  **Identify Keywords:** Determine the key concepts, tools, or procedures relevant to the current task.
2.  **Scan KB:**
    *   a. **Read `README.md`:** Always start by reading the `.ruru/modes/dev-solver/kb/README.md` for an overview and structure guidance.
    *   b. **List Contents:** Identify relevant files and subdirectories within `.ruru/modes/dev-solver/kb/`.
    *   c. **Prioritize Top-Level:** Review relevant top-level `.md` files first.
    *   d. **Explore Subdirectories:** If keywords, task context, or the `README.md` suggest relevance, explore pertinent subdirectories. Look for `README.md` or index files within them.
    *   e. **Review Content:** Read the content of potentially relevant files identified.
3.  **Apply Knowledge / Execute:**
    *   **IF** sufficient information was found in the KB: Integrate it into your task execution plan and response. Proceed with execution.
    *   **ELSE IF** KB was consulted but insufficient (and task was complex/uncertain): Proceed to Step 4.
    *   **ELSE (KB was skipped for simple task):** Proceed with execution using core capabilities and general knowledge.

**4. Information Gathering (If KB Insufficient for Complex/Uncertain Task):**
    *   **Identify Information Need:** Clearly state what specific information or clarification is missing to proceed reliably.
    *   **Propose Next Steps:** Use the ask_followup_question tool to propose information-gathering actions to the coordinator/user. Suggestions **MUST** include context-appropriate options like:
        *   "Search external documentation/web using [Specific MCP Tool, e.g., `vertex-ai-mcp-server/answer_query_websearch`] for [topic/error]." (Mention specific tool and query).
        *   "Read a specific file if you can provide the path."
        *   "Ask for clarification on [specific aspect of the task]."
        *   "Attempt the task using general knowledge (state potential risks/uncertainties)."
    *   **Await Guidance:** Do not proceed with the original task until guidance is received on how to gather the missing information.

## Knowledge Base Index

*This section provides an overview and index of the knowledge base documents available for the `dev-solver` mode. Use this index to quickly locate relevant information for the task at hand.*

*   `debugging_techniques/index.toml`: Master index for the debugging techniques library.
*   `synthesized/foundations/core_techniques.md`: Summary of foundational debugging techniques including debuggers, print/logging, rubber ducking, bug reproduction, VCS analysis, static analysis, and testing.
*   `synthesized/foundations/setup-summary.md`: Brief overview of setting up debugging tools, emphasizing IDE integration and language-specific requirements.
*   `synthesized/foundations/general-summary.md`: High-level overview of debugging, covering its purpose and the spectrum of techniques from foundational to advanced.
*   `synthesized/advanced/concurrency_debugging.md`: Addresses challenges and techniques for debugging issues in multi-threaded or concurrent programs, such as race conditions and deadlocks.
*   `synthesized/advanced/distributed_systems_debugging.md`: Covers the complexities and strategies for debugging applications composed of multiple interacting services across a network.
*   `synthesized/advanced/dynamic_analysis.md`: Explanation of dynamic analysis techniques used for debugging software during runtime execution.
*   `synthesized/advanced/memory_debugging.md`: Focuses on techniques and tools for finding memory-related bugs like leaks, buffer overflows, and use-after-free errors.
*   `synthesized/advanced/performance_profiling.md`: Using profiling tools to analyze application performance, identify bottlenecks, and optimize resource usage (CPU, memory, I/O).
*   `synthesized/advanced/post_mortem.md`: Debugging using information collected after a program has crashed or terminated abnormally, typically via core dumps or crash logs.
*   `synthesized/advanced/reverse_debugging.md`: Explanation of reverse debugging, allowing developers to step backward in execution time to find the origin of bugs.

*(Maintainers: Keep this index up-to-date as KB files are added, removed, or reorganized. Provide a concise, informative summary for each entry to aid AI navigation.)*


**Rationale:** This rule balances efficiency for simple tasks with robust handling of complex/uncertain tasks. It mandates KB consultation when needed and provides a structured way to seek further information (internally or externally via MCP/user) when the KB is insufficient, reducing errors and improving task success rates.
