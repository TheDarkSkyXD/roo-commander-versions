# 09 Reference

This section contains reference materials such as the glossary of terms and a full list of available modes within Roo Commander.

## Files in this section

*   [01 Glossary](01_Glossary.md)
*   [02 Full Mode List](02_Full_Mode_List.md)

[Back to Main KB README](../README.md)